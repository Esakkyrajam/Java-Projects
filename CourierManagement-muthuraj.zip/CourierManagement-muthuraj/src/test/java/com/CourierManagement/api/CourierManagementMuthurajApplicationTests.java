package com.CourierManagement.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourierManagementMuthurajApplicationTests {

	@Test
	void contextLoads() {
	}

}
